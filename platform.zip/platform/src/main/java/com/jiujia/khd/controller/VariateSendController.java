package com.jiujia.khd.controller;

import com.jiujia.common.core.controller.BaseController;
import com.jiujia.common.core.domain.AjaxResult;
import com.jiujia.common.core.domain.entity.SysUser;
import com.jiujia.common.utils.poi.ExcelUtil;
import com.jiujia.khd.domain.TApplication;
import com.jiujia.khd.domain.TModel;
import com.jiujia.khd.service.ITApplicationService;
import com.jiujia.khd.service.ITModelService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @description: 变量下发
 * @author: qklv
 * @create: 2022-02-10 14:27
 */
@Controller
@RequestMapping("/mmskhd/variatesendlist")
public class VariateSendController  extends BaseController {

    private String prefix="mmskhd/variatesendlist";

    @Autowired
    private ITApplicationService tApplicationService;

    @Autowired
    private ITModelService tModelService;

    @RequiresPermissions("mmskhd:variatesendlist:view")
    @GetMapping()
    public String variatesendlist(ModelMap mmap){
        TApplication tApplication = new TApplication();
        tApplication.setCompanyId(getcompanyId());
        tApplication.setStatus("normal");

        TModel tModel = new TModel();
        tModel.setVariate("variate");
        mmap.put("modelList", tModelService.selectTModelList(tModel));
        mmap.put("appList", tApplicationService.selectTApplicationList(tApplication));

        return prefix + "/variatesendlist";
    }

    @RequiresPermissions("mmskhd:variatesendlist:send")
    @GetMapping("/send")
    public AjaxResult list(MultipartFile file, String appId, String modelId , String isTime, String time)  throws Exception{

        ExcelUtil<SysUser> util = new ExcelUtil<SysUser>(SysUser.class);
        List<SysUser> userList = util.importExcel(file.getInputStream());
        return null;
    }

}

package com.jiujia.khd.service;

import java.util.Map;

/**
 * @author WHY
 * @date 2022年03月06日 19:45
 */
public interface DataStatisticAppChannelService {

    //首页-月统计
    Map getMonthStatistics();

}
